# safeCampus
campus Safety application for android
<h1> Features </h1><br>
1 Easy to understand<br>
2 Shake detector<br>
3 safety tips<br>
4 Call to registered security guard mobile numbers<br>
5 Shake device to send emergency text to registered mobile and play siren<br>
6 Sends Last Known Location to registered mobile.<br>
7 Now we can add multiple contacts to send emergency text<br>
8 University safe zone areas map.<br><br>
<h1> Prerequisites :</h1><br>

Android Studio Basic knowledge about Realtime database.<br>
Build and Run Application<br>
Safe women at campus A Women Safety Application requires Android Oreo or newer version to run.<br><br><br


<h1> Follow this steps to get Working Project!</h1><br>
Clone this repository or download file<br>
Extract zip if downloaded code<br>
Open project in Android Studio<br>
Wait while Android Studio Download gradle or required files<br>
Hit Run Button !<br>

<h1> Main screen </h1><br>

<img height="550" src="images/1.jpeg" width="350"/>
<h1> Menu screen </h1><br>

<img height="550" src="images/2.jpeg" width="350"/>
<h1> Emergency Call screen </h1><br>
![](images/3.jpeg)

<h1> Safety tips screen </h1><br>

<img height="550" src="images/4.jpeg" width="350"/>
<h1> Maps screen </h1><br>

<img height="550" src="images/5.jpeg" width="350"/>