package com.example.safecampus;

public interface MyOnClickListener {
    void onItemClicked(int position);
}
